# spring_data
Mã nguồn Spring Data được sử dụng để thực hành tại [CodeGym](https://codegym.vn)

# Các dự án
- customer-management

- customer-management-jpa 

- customer-management-stored-procedure

- customer-province-management

- paging-and-sorting
