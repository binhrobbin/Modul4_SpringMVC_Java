package vn.codegym.model;

public class StudentCourse {

}
