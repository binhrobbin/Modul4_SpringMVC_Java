package vn.codegym.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Component
@Configuration
public class XYZ {

    @Bean
    public void abc(){

    }
}
